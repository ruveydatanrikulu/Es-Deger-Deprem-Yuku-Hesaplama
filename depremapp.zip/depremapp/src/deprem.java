import javax.swing.*;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import static java.lang.Integer.parseInt;
import static java.lang.Integer.valueOf;

public class deprem extends JFrame {
    private JPanel panel1;
    private JButton hesaplaButton;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
    private JLabel label1;
    private JLabel image;
    private JLabel f1;
    private JLabel f2;
    private JLabel f3;

    public deprem() {
        add(panel1);
        setSize(900, 800);
        setTitle("EŞDEĞER DEPREM YÜKÜ HESABI");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);


        hesaplaButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                double g1, q1, sds1, sd1;
                double r = 8, d = 3;
                double t = 0.3;
                double wsonuc, toplamw;
                double sae = 0;
                double ra = 0;
                double tl = 6, ta, tb;
                double sar, mt;
                double yerg = 9.81, vt;
                double n = 3, fn;
                double vtfn, wh,wh1,wh2,toplamwh;
                double a1,a2,a3;
                double c1,c2,c3;
                double fi1,fi2,fi3;


                String g, q, sds, sd;

                g = textField1.getText();
                q = textField2.getText();
                sds = textField3.getText();
                sd = textField4.getText();

                g1 = Double.parseDouble(g);
                q1 = Double.parseDouble(q);
                sds1 = Double.parseDouble(sds);
                sd1 = Double.parseDouble(sd);

                wsonuc = (g1 + (t * q1));
                toplamw = wsonuc * 3;

                ta = (0.2 * (sd1 / sds1));
                tb = sd1 / sds1;

                if (0 <= t && t <= ta) {
                    sae = (0.4 + (0.6 * (t / ta)));
                } else if (ta <= t && t <= tb) {
                    sae = sds1;
                    ra = d + (r - d) * (t / tb);
                } else if (tb <= t && t <= tl) {
                    sae = sd1 / t;
                    ra = r / 1;

                } else if (tl <= t) {
                    sae = (sd1 * tl) / (t * t);
                }
                sar = sae / ra;
                mt = toplamw / yerg;
                vt = mt * ((sae * yerg) / ra);
                fn = 0.0075 * n * vt;
                label1.setText(String.valueOf(vt));
                vtfn=vt-fn;
                wh=wsonuc*9;
                wh1=wsonuc*6;
                wh2=wsonuc*3;
                toplamwh=wh+wh1+wh2;
                a1=wh/toplamwh;
                a2=wh1/toplamwh;
                a3=wh2/toplamwh;
                c1=a1*vtfn;
                c2=a2*vtfn;
                c3=a3*vtfn;
                fi1=c1+fn;
                fi2=c2;
                fi3=c3;
                f1.setText(String.valueOf(fi1));
                f2.setText(String.valueOf(fi2));
                f3.setText(String.valueOf(fi3));

            }

        });
    }

    private void createUIComponents() {
        image =new JLabel(new ImageIcon("resim.png"));





    }
}
